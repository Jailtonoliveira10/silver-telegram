import { Player } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { useLanguage } from "@/hooks/use-language";
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
  ResponsiveContainer
} from "recharts";

interface PlayerComparisonProps {
  players: Player[];
  isLoading: boolean;
}

export default function PlayerComparison({ players, isLoading }: PlayerComparisonProps) {
  const { t } = useLanguage();
  const [selectedPlayers, setSelectedPlayers] = useState<string[]>([]);

  // Métricas avançadas para comparação
  const metrics = [
    { id: 'goals', label: t('goals'), maxValue: 40 },
    { id: 'assists', label: t('assists'), maxValue: 30 },
    { id: 'games', label: t('games'), maxValue: 50 },
    { id: 'rating', label: t('rating'), maxValue: 10 },
    { id: 'performance_index', label: t('performance_index'), maxValue: 100 },
    { id: 'potential_growth', label: t('potential_growth'), maxValue: 100 }
  ];

  // Calcular índice de desempenho e potencial de crescimento
  const calculatePerformanceIndex = (player: Player) => {
    const gamesWeight = 0.2;
    const goalsWeight = 0.3;
    const assistsWeight = 0.2;
    const ratingWeight = 0.3;

    const gamesScore = (player.stats.games / 50) * 100;
    const goalsScore = (player.stats.goals / 40) * 100;
    const assistsScore = (player.stats.assists / 30) * 100;
    const ratingScore = (parseFloat(player.stats.rating) / 10) * 100;

    return (
      gamesScore * gamesWeight +
      goalsScore * goalsWeight +
      assistsScore * assistsWeight +
      ratingScore * ratingWeight
    );
  };

  const calculatePotentialGrowth = (player: Player) => {
    // Fórmula simplificada para potencial baseada na idade
    const idealAge = 25;
    const ageFactor = player.age <= idealAge 
      ? ((idealAge - player.age) / idealAge) * 100
      : Math.max(0, (40 - player.age) / 15 * 100);

    const performanceBonus = calculatePerformanceIndex(player) * 0.3;
    return Math.min(100, ageFactor + performanceBonus);
  };

  // Preparar dados para o gráfico de radar
  const radarData = metrics.map(metric => {
    const data: any = { subject: metric.label };
    selectedPlayers.forEach(playerId => {
      const player = players.find(p => p.id.toString() === playerId);
      if (player) {
        let value = 0;
        switch (metric.id) {
          case 'goals':
            value = player.stats.goals;
            break;
          case 'assists':
            value = player.stats.assists;
            break;
          case 'games':
            value = player.stats.games;
            break;
          case 'rating':
            value = parseFloat(player.stats.rating);
            break;
          case 'performance_index':
            value = calculatePerformanceIndex(player);
            break;
          case 'potential_growth':
            value = calculatePotentialGrowth(player);
            break;
        }
        data[player.name] = value;
      }
    });
    return data;
  });

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle>{t('player_comparison')}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex gap-4">
            <div className="w-48">
              <Select 
                value={selectedPlayers[0]} 
                onValueChange={(value) => setSelectedPlayers(prev => [value, prev[1]])}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t('select_player_1')} />
                </SelectTrigger>
                <SelectContent>
                  {players.map(player => (
                    <SelectItem key={player.id} value={player.id.toString()}>
                      {player.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="w-48">
              <Select 
                value={selectedPlayers[1]} 
                onValueChange={(value) => setSelectedPlayers(prev => [prev[0], value])}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t('select_player_2')} />
                </SelectTrigger>
                <SelectContent>
                  {players.map(player => (
                    <SelectItem key={player.id} value={player.id.toString()}>
                      {player.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {selectedPlayers.length === 2 && (
            <div className="space-y-8">
              <div className="h-[500px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" />
                    <PolarRadiusAxis />
                    {selectedPlayers.map(playerId => {
                      const player = players.find(p => p.id.toString() === playerId);
                      if (player) {
                        return (
                          <Radar
                            key={player.id}
                            name={player.name}
                            dataKey={player.name}
                            stroke={player.id % 2 === 0 ? "hsl(var(--primary))" : "#82ca9d"}
                            fill={player.id % 2 === 0 ? "hsl(var(--primary))" : "#82ca9d"}
                            fillOpacity={0.6}
                          />
                        );
                      }
                      return null;
                    })}
                    <Legend />
                  </RadarChart>
                </ResponsiveContainer>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {selectedPlayers.map(playerId => {
                  const player = players.find(p => p.id.toString() === playerId);
                  if (player) {
                    return (
                      <Card key={player.id}>
                        <CardHeader>
                          <CardTitle className="text-lg">{player.name}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <dl className="space-y-2">
                            <div className="flex justify-between">
                              <dt>{t('performance_index')}</dt>
                              <dd className="font-medium">
                                {calculatePerformanceIndex(player).toFixed(1)}
                              </dd>
                            </div>
                            <div className="flex justify-between">
                              <dt>{t('potential_growth')}</dt>
                              <dd className="font-medium">
                                {calculatePotentialGrowth(player).toFixed(1)}%
                              </dd>
                            </div>
                          </dl>
                        </CardContent>
                      </Card>
                    );
                  }
                  return null;
                })}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}