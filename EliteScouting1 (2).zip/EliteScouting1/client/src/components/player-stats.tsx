import { Player } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

interface PlayerStatsProps {
  players: Player[];
  isLoading: boolean;
  onFilterChange: (filters: any) => void;
}

export default function PlayerStats({ players, isLoading, onFilterChange }: PlayerStatsProps) {
  const { t } = useLanguage();
  const positions = ["Forward", "Midfielder", "Defender", "Goalkeeper"];
  const [searchQuery, setSearchQuery] = useState("");

  // Filtrar jogadores localmente baseado na busca
  const displayPlayers = players.filter(player => 
    searchQuery.length > 0 
      ? player.name.toLowerCase().includes(searchQuery.toLowerCase())
      : true
  );

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="col-span-2">
          <Label>{t('search_player')}</Label>
          <Input
            placeholder={t('search_player_placeholder')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="mt-2"
          />
        </div>
        <div className="space-y-2">
          <Label>{t('position')}</Label>
          <Select onValueChange={(value) => onFilterChange((prev: any) => ({ ...prev, positions: [value] }))}>
            <SelectTrigger>
              <SelectValue placeholder={t('all_positions')} />
            </SelectTrigger>
            <SelectContent>
              {positions.map(pos => (
                <SelectItem key={pos} value={pos}>{t(pos.toLowerCase())}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="relative">
            {isLoading && (
              <div className="absolute inset-0 bg-background/50 flex items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin" />
              </div>
            )}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="p-4 text-left">{t('name')}</th>
                    <th className="p-4 text-left">{t('nationality')}</th>
                    <th className="p-4 text-left">{t('position')}</th>
                    <th className="p-4 text-left">{t('age')}</th>
                    <th className="p-4 text-left">{t('club')}</th>
                    <th className="p-4 text-left">{t('games')}</th>
                    <th className="p-4 text-left">{t('goals')}</th>
                    <th className="p-4 text-left">{t('assists')}</th>
                    <th className="p-4 text-left">{t('rating')}</th>
                  </tr>
                </thead>
                <tbody>
                  {displayPlayers.map(player => (
                    <tr key={player.id} className="border-b hover:bg-muted/50 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{player.name}</span>
                          <span className="text-sm text-muted-foreground">
                            {player.stats.rating !== '0.0' && `${player.stats.rating}`}
                          </span>
                        </div>
                      </td>
                      <td className="p-4">{player.nationality}</td>
                      <td className="p-4">{player.position}</td>
                      <td className="p-4">{player.age}</td>
                      <td className="p-4">{player.club}</td>
                      <td className="p-4">{player.stats.games || 0}</td>
                      <td className="p-4">{player.stats.goals || 0}</td>
                      <td className="p-4">{player.stats.assists || 0}</td>
                      <td className="p-4">{player.stats.rating !== '0.0' ? player.stats.rating : '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}