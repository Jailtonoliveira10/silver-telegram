import { useState } from "react";
import { Button } from "@/components/ui/button";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export function TwoFactorAuth() {
  const { t } = useLanguage();
  const { user, enable2FAMutation, verify2FAMutation, disable2FAMutation } = useAuth();
  const [verificationCode, setVerificationCode] = useState("");
  const [qrCode, setQrCode] = useState<string | null>(null);

  const handleEnable2FA = async () => {
    try {
      const result = await enable2FAMutation.mutateAsync();
      setQrCode(result.qrCodeUrl);
    } catch (error) {
      console.error('Error enabling 2FA:', error);
    }
  };

  const handleVerify2FA = async () => {
    try {
      await verify2FAMutation.mutateAsync({ token: verificationCode });
      setQrCode(null);
      setVerificationCode("");
    } catch (error) {
      console.error('Error verifying 2FA:', error);
    }
  };

  const handleDisable2FA = async () => {
    try {
      await disable2FAMutation.mutateAsync();
    } catch (error) {
      console.error('Error disabling 2FA:', error);
    }
  };

  if (!user) return null;

  return (
    <Card className="p-6 space-y-4">
      <h2 className="text-2xl font-semibold">{t('two_factor_auth')}</h2>

      {user.twoFactorEnabled ? (
        <div className="space-y-4">
          <p className="text-green-600">{t('2fa_enabled')}</p>
          <Button
            variant="destructive"
            onClick={handleDisable2FA}
            disabled={disable2FAMutation.isPending}
          >
            {disable2FAMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : null}
            {t('disable_2fa')}
          </Button>
        </div>
      ) : qrCode ? (
        <div className="space-y-4">
          <p>{t('scan_qr_code')}</p>
          <div className="flex justify-center">
            <img src={qrCode} alt="QR Code" className="w-64 h-64" />
          </div>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">{t('enter_verification_code')}</p>
            <InputOTP
              value={verificationCode}
              onChange={setVerificationCode}
              maxLength={6}
              render={({ slots }) => (
                <InputOTPGroup>
                  {slots.map((slot, idx) => (
                    <InputOTPSlot key={idx} index={idx} {...slot} />
                  ))}
                </InputOTPGroup>
              )}
            />
            <Button
              onClick={handleVerify2FA}
              disabled={verify2FAMutation.isPending || verificationCode.length !== 6}
              className="w-full"
            >
              {verify2FAMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              {t('verify')}
            </Button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <p>{t('2fa_description')}</p>
          <Button
            onClick={handleEnable2FA}
            disabled={enable2FAMutation.isPending}
            className="w-full"
          >
            {enable2FAMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : null}
            {t('enable_2fa')}
          </Button>
        </div>
      )}
    </Card>
  );
}