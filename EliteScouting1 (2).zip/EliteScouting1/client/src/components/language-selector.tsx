import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLanguage } from "@/hooks/use-language";

export function LanguageSelector() {
  const { language, setLanguage, t } = useLanguage();

  // Mapeamento de idiomas com suas bandeiras e traduções
  const languageOptions = {
    pt: { flag: "🇧🇷", label: t('languages.portuguese') },
    en: { flag: "🇺🇸", label: t('languages.english') },
    es: { flag: "🇪🇸", label: t('languages.spanish') }
  };

  return (
    <Select 
      value={language} 
      onValueChange={(value: 'pt' | 'en' | 'es') => setLanguage(value)}
    >
      <SelectTrigger className="w-[180px] h-10">
        <SelectValue>
          <div className="flex items-center gap-2">
            <span className="text-lg leading-none">{languageOptions[language].flag}</span>
            <span className="truncate">{languageOptions[language].label}</span>
          </div>
        </SelectValue>
      </SelectTrigger>
      <SelectContent 
        align="center" 
        className="min-w-[180px]"
        sideOffset={4}
      >
        {Object.entries(languageOptions).map(([code, { flag, label }]) => (
          <SelectItem 
            key={code} 
            value={code}
            className="flex items-center gap-2 h-10 px-3"
          >
            <span className="text-lg leading-none">{flag}</span>
            <span className="truncate">{label}</span>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}