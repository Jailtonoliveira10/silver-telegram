import nodemailer from 'nodemailer';
import { Player } from '@shared/schema';
import { sendWhatsAppMessage } from './services/whatsapp';

const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER || "test@example.com",
    pass: process.env.EMAIL_PASS || "password"
  }
});

export async function sendPlayerAlert(
  userEmail: string, 
  player: Player,
  reason: string,
  whatsappNumber?: string
) {
  const mailOptions = {
    from: process.env.EMAIL_USER || "test@example.com",
    to: userEmail,
    subject: `Alerta de Jogador: ${player.name}`,
    html: `
      <h2>Alerta de Atualização de Jogador</h2>
      <p><strong>Jogador:</strong> ${player.name}</p>
      <p><strong>Clube:</strong> ${player.club}</p>
      <p><strong>Valor de Mercado:</strong> €${(player.marketValue/1000000).toFixed(1)}M</p>
      <p><strong>Motivo:</strong> ${reason}</p>
    `
  };

  let emailSuccess = false;
  let whatsappSuccess = false;

  try {
    await transporter.sendMail(mailOptions);
    emailSuccess = true;
  } catch (error) {
    console.error('Falha ao enviar email:', error);
  }

  if (whatsappNumber) {
    const message = `🚨 Alerta: ${player.name}\n` +
      `⚽ Clube: ${player.club}\n` +
      `💰 Valor: €${(player.marketValue/1000000).toFixed(1)}M\n` +
      `📝 Motivo: ${reason}`;

    try {
      whatsappSuccess = await sendWhatsAppMessage({
        to: whatsappNumber,
        message: message
      });
    } catch (error) {
      console.error('Falha ao enviar WhatsApp:', error);
    }
  }

  return emailSuccess || whatsappSuccess;
}