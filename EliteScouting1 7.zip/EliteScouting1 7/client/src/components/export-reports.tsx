import { Button } from '@/components/ui/button';
import { jsPDF } from 'jspdf';
import * as XLSX from 'xlsx';
import { useLanguage } from '@/hooks/use-language';
import { Download } from 'lucide-react';
import { Player } from '@shared/schema';

interface ExportReportsProps {
  players: Player[];
  type: 'stats' | 'market';
}

export default function ExportReports({ players, type }: ExportReportsProps) {
  const { t } = useLanguage();

  const formatData = () => {
    if (type === 'stats') {
      return players.map(player => ({
        Nome: player.name,
        Posição: player.position,
        Idade: player.age,
        'Valor de Mercado': new Intl.NumberFormat('pt-BR', {
          style: 'currency',
          currency: 'EUR'
        }).format(player.marketValue)
      }));
    } else {
      return players.map(player => ({
        Nome: player.name,
        'Valor Atual': new Intl.NumberFormat('pt-BR', {
          style: 'currency',
          currency: 'EUR'
        }).format(player.marketValue),
        'Variação (%)': '10%' // Exemplo - substituir por dados reais
      }));
    }
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    const title = type === 'stats' ? t('player_stats') : t('market_history');
    
    // Add title
    doc.setFontSize(20);
    doc.text(title, 20, 20);
    
    // Add date
    doc.setFontSize(12);
    doc.text(`${t('generated_at')}: ${new Date().toLocaleDateString()}`, 20, 30);
    
    // Add data
    const data = formatData();
    let y = 40;
    
    // Add headers
    const headers = Object.keys(data[0]);
    doc.setFont('helvetica', 'bold');
    headers.forEach((header, index) => {
      doc.text(header, 20 + (index * 50), y);
    });
    
    // Add rows
    doc.setFont('helvetica', 'normal');
    data.forEach(row => {
      y += 10;
      if (y > 280) { // Check if we need a new page
        doc.addPage();
        y = 20;
      }
      Object.values(row).forEach((value, index) => {
        doc.text(String(value), 20 + (index * 50), y);
      });
    });
    
    doc.save(`relatorio_${type}_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  const exportToExcel = () => {
    const data = formatData();
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, type === 'stats' ? t('player_stats') : t('market_history'));
    XLSX.writeFile(wb, `relatorio_${type}_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="flex gap-2 mt-4">
      <Button onClick={exportToPDF} variant="outline" size="sm">
        <Download className="h-4 w-4 mr-2" />
        {t('export_pdf')}
      </Button>
      <Button onClick={exportToExcel} variant="outline" size="sm">
        <Download className="h-4 w-4 mr-2" />
        {t('export_excel')}
      </Button>
    </div>
  );
}
