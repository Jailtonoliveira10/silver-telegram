import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { insertUserSchema } from "@shared/schema";
import { useLocation } from "wouter";
import { IoFootball } from "react-icons/io5";
import { LanguageSelector } from "@/components/language-selector";
import { Loader2 } from "lucide-react";
import * as z from "zod";
import { SiGoogle } from "react-icons/si";

function createValidationSchemas(t: (key: string) => string) {
  const loginSchema = insertUserSchema.pick({ username: true, password: true }).extend({
    username: z.string()
      .min(3, t('username_min_length'))
      .max(50, t('username_max_length')),
    password: z.string()
      .min(8, t('password_min_length'))
      .max(100, t('password_max_length'))
      .regex(/[A-Z]/, t('password_uppercase'))
      .regex(/[0-9]/, t('password_number'))
  });

  const registerSchema = insertUserSchema.extend({
    username: z.string()
      .min(3, t('username_min_length'))
      .max(50, t('username_max_length')),
    password: z.string()
      .min(8, t('password_min_length'))
      .max(100, t('password_max_length'))
      .regex(/[A-Z]/, t('password_uppercase'))
      .regex(/[0-9]/, t('password_number')),
    email: z.string()
      .email(t('email_invalid'))
  });

  return { loginSchema, registerSchema };
}

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const { t } = useLanguage();
  const [, setLocation] = useLocation();

  // Redirect if already logged in
  if (user) {
    setLocation("/");
    return null;
  }

  const { loginSchema, registerSchema } = createValidationSchemas(t);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted flex items-center justify-center p-4">
      <div className="absolute top-4 right-4">
        <LanguageSelector />
      </div>
      <div className="w-full max-w-5xl grid md:grid-cols-2 gap-8 items-center">
        <Card className="w-full border-primary/10 shadow-lg transition-all duration-300 hover:shadow-xl hover:border-primary/20">
          <CardHeader className="space-y-2">
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/50 bg-clip-text text-transparent">
              Elite Scouting Network
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              {t('sign_in_description')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login" className="transition-all duration-300 ease-in-out">{t('login')}</TabsTrigger>
                <TabsTrigger value="register" className="transition-all duration-300 ease-in-out">{t('register')}</TabsTrigger>
              </TabsList>
              <TabsContent value="login" className="mt-0">
                <LoginForm schema={loginSchema} />
              </TabsContent>
              <TabsContent value="register" className="mt-0">
                <RegisterForm schema={registerSchema} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <div className="hidden md:block text-center space-y-8">
          <div className="relative">
            <div className="absolute inset-0 bg-primary/5 blur-3xl rounded-full animate-pulse transition-opacity duration-1000"></div>
            <IoFootball className="w-24 h-24 mx-auto text-primary relative animate-[bounce_2s_ease-in-out_infinite]" />
          </div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/50 bg-clip-text text-transparent">
            Elite Scouting Network
          </h2>
          <p className="text-muted-foreground max-w-md mx-auto text-lg">
            {t('market_intelligence')}
          </p>
        </div>
      </div>
    </div>
  );
}

function LoginForm({ schema }: { schema: z.ZodType<any> }) {
  const { loginMutation } = useAuth();
  const { t } = useLanguage();
  const form = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      username: "",
      password: ""
    }
  });

  const handleGoogleLogin = () => {
    window.location.href = '/auth/google';
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit((data) => loginMutation.mutate(data))} className="space-y-4">
        <FormField
          control={form.control}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('username')}</FormLabel>
              <FormControl>
                <Input {...field} autoComplete="username" autoFocus className="transition-all duration-200 focus:border-primary/50" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('password')}</FormLabel>
              <FormControl>
                <Input type="password" {...field} autoComplete="current-password" className="transition-all duration-200 focus:border-primary/50" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="space-y-2">
          <Button
            type="submit"
            className="w-full transition-all duration-200 hover:bg-primary/90"
            disabled={loginMutation.isPending}
          >
            {loginMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {t('logging_in')}
              </>
            ) : (
              t('login')
            )}
          </Button>

          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">
                {t('or_continue_with')}
              </span>
            </div>
          </div>

          <Button
            type="button"
            variant="outline"
            className="w-full transition-all duration-200 hover:bg-primary/10"
            onClick={handleGoogleLogin}
          >
            <SiGoogle className="mr-2 h-4 w-4" />
            {t('continue_with_google')}
          </Button>
        </div>
      </form>
    </Form>
  );
}

function RegisterForm({ schema }: { schema: z.ZodType<any> }) {
  const { registerMutation } = useAuth();
  const { t } = useLanguage();
  const form = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      username: "",
      password: "",
      email: ""
    }
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit((data) => registerMutation.mutate(data))} className="space-y-4">
        <FormField
          control={form.control}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('username')}</FormLabel>
              <FormControl>
                <Input {...field} autoComplete="username" autoFocus className="transition-all duration-200 focus:border-primary/50" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('email')}</FormLabel>
              <FormControl>
                <Input type="email" {...field} autoComplete="email" className="transition-all duration-200 focus:border-primary/50" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('password')}</FormLabel>
              <FormControl>
                <Input type="password" {...field} autoComplete="new-password" className="transition-all duration-200 focus:border-primary/50" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button
          type="submit"
          className="w-full transition-all duration-200 hover:bg-primary/90"
          disabled={registerMutation.isPending}
        >
          {registerMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {t('registering')}
            </>
          ) : (
            t('register')
          )}
        </Button>
      </form>
    </Form>
  );
}