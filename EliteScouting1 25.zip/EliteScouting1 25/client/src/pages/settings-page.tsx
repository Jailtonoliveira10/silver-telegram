import { TwoFactorAuth } from "@/components/two-factor-auth";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { Card } from "@/components/ui/card";

export default function SettingsPage() {
  const { t } = useLanguage();
  const { user } = useAuth();

  if (!user) return null;

  return (
    <div className="container mx-auto py-8 space-y-6">
      <h1 className="text-3xl font-bold">{t('settings')}</h1>
      
      <div className="grid gap-6">
        <Card className="p-6">
          <h2 className="text-2xl font-semibold mb-4">{t('security')}</h2>
          <TwoFactorAuth />
        </Card>
      </div>
    </div>
  );
}
