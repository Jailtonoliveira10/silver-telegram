import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { AlertPreferences } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { useState, useEffect } from "react";
import { Bell, BellOff, MessageSquare } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

const positions = ["Forward", "Midfielder", "Defender", "Goalkeeper"];

export default function AlertSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { t } = useLanguage();

  const defaultPreferences: AlertPreferences = {
    positions: [],
    minMarketValue: 0,
    maxMarketValue: 100000000,
    ageRange: [16, 40],
    notificationEnabled: true,
    whatsappNumber: "",
    whatsappEnabled: false,
    alertTypes: {
      marketValue: true,
      performance: true,
      injury: true,
      transfer: true
    }
  };

  const [preferences, setPreferences] = useState<AlertPreferences>(defaultPreferences);

  // Use useEffect para atualizar as preferências quando o usuário estiver disponível
  useEffect(() => {
    if (user?.alertPreferences) {
      setPreferences(user.alertPreferences);
    }
  }, [user]);

  const updatePreferences = useMutation({
    mutationFn: async (prefs: AlertPreferences) => {
      const res = await apiRequest("PATCH", "/api/users/alert-preferences", prefs);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Preferências Atualizadas",
        description: "Suas configurações de alerta foram salvas com sucesso.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao Atualizar",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const testAlert = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/alerts/test");
    },
    onSuccess: () => {
      toast({
        title: "Alerta de Teste Enviado",
        description: "Verifique seu email e WhatsApp para o alerta de teste.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro no Teste",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {preferences.notificationEnabled ? (
              <Bell className="h-5 w-5 text-primary" />
            ) : (
              <BellOff className="h-5 w-5 text-muted-foreground" />
            )}
            {t('notification_settings')}
          </CardTitle>
          <CardDescription>
            Configure quando e como você quer receber alertas sobre jogadores
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Email Notifications */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('email_notifications')}</Label>
              <div className="text-sm text-muted-foreground">
                Receber alertas sobre atualizações e mudanças no mercado
              </div>
            </div>
            <Switch
              checked={preferences.notificationEnabled}
              onCheckedChange={(checked) =>
                setPreferences((prev) => ({
                  ...prev,
                  notificationEnabled: checked,
                }))
              }
            />
          </div>

          {/* WhatsApp Notifications */}
          <div className="space-y-4 border-t pt-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Notificações WhatsApp
                </Label>
                <div className="text-sm text-muted-foreground">
                  Receber alertas instantâneos via WhatsApp
                </div>
              </div>
              <Switch
                checked={preferences.whatsappEnabled}
                onCheckedChange={(checked) =>
                  setPreferences((prev) => ({
                    ...prev,
                    whatsappEnabled: checked,
                  }))
                }
              />
            </div>

            {preferences.whatsappEnabled && (
              <div className="space-y-2">
                <Label>Número do WhatsApp</Label>
                <Input
                  placeholder="+55 (11) 99999-9999"
                  value={preferences.whatsappNumber}
                  onChange={(e) =>
                    setPreferences((prev) => ({
                      ...prev,
                      whatsappNumber: e.target.value,
                    }))
                  }
                />
                <p className="text-sm text-muted-foreground">
                  Inclua o código do país e DDD
                </p>
              </div>
            )}
          </div>

          {/* Alert Types */}
          <div className="space-y-4 border-t pt-4">
            <Label>Tipos de Alerta</Label>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={preferences.alertTypes.marketValue}
                  onCheckedChange={(checked) =>
                    setPreferences((prev) => ({
                      ...prev,
                      alertTypes: {
                        ...prev.alertTypes,
                        marketValue: checked,
                      },
                    }))
                  }
                />
                <Label>Valor de Mercado</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  checked={preferences.alertTypes.performance}
                  onCheckedChange={(checked) =>
                    setPreferences((prev) => ({
                      ...prev,
                      alertTypes: {
                        ...prev.alertTypes,
                        performance: checked,
                      },
                    }))
                  }
                />
                <Label>Desempenho</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  checked={preferences.alertTypes.injury}
                  onCheckedChange={(checked) =>
                    setPreferences((prev) => ({
                      ...prev,
                      alertTypes: {
                        ...prev.alertTypes,
                        injury: checked,
                      },
                    }))
                  }
                />
                <Label>Lesões</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  checked={preferences.alertTypes.transfer}
                  onCheckedChange={(checked) =>
                    setPreferences((prev) => ({
                      ...prev,
                      alertTypes: {
                        ...prev.alertTypes,
                        transfer: checked,
                      },
                    }))
                  }
                />
                <Label>Transferências</Label>
              </div>
            </div>
          </div>

          {/* Positions and Range Settings */}
          <div className="space-y-4 border-t pt-4">
            <div>
              <Label>{t('positions_of_interest')}</Label>
              <ToggleGroup
                type="multiple"
                className="justify-start mt-2"
                value={preferences.positions}
                onValueChange={(value) =>
                  setPreferences((prev) => ({ ...prev, positions: value }))
                }
              >
                {positions.map((position) => (
                  <ToggleGroupItem
                    key={position}
                    value={position}
                    className="px-3"
                  >
                    {t(position.toLowerCase())}
                  </ToggleGroupItem>
                ))}
              </ToggleGroup>
            </div>

            <div className="space-y-2">
              <Label>{t('market_value_range')} (€M)</Label>
              <div className="pt-2">
                <Slider
                  min={0}
                  max={200}
                  step={5}
                  value={[
                    preferences.minMarketValue / 1000000,
                    preferences.maxMarketValue / 1000000,
                  ]}
                  onValueChange={([min, max]) =>
                    setPreferences((prev) => ({
                      ...prev,
                      minMarketValue: min * 1000000,
                      maxMarketValue: max * 1000000,
                    }))
                  }
                />
              </div>
              <div className="flex justify-between">
                <Badge variant="outline">
                  €{preferences.minMarketValue / 1000000}M
                </Badge>
                <Badge variant="outline">
                  €{preferences.maxMarketValue / 1000000}M
                </Badge>
              </div>
            </div>

            <div className="space-y-2">
              <Label>{t('age_range')}</Label>
              <div className="pt-2">
                <Slider
                  min={16}
                  max={40}
                  step={1}
                  value={preferences.ageRange}
                  onValueChange={(value) =>
                    setPreferences((prev) => ({
                      ...prev,
                      ageRange: value as [number, number],
                    }))
                  }
                />
              </div>
              <div className="flex justify-between">
                <Badge variant="outline">{preferences.ageRange[0]} anos</Badge>
                <Badge variant="outline">{preferences.ageRange[1]} anos</Badge>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-4 border-t">
            <Button
              onClick={() => updatePreferences.mutate(preferences)}
              disabled={updatePreferences.isPending}
            >
              {t('save_preferences')}
            </Button>
            <Button
              variant="outline"
              onClick={() => testAlert.mutate()}
              disabled={testAlert.isPending}
            >
              {t('test_alert')}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}