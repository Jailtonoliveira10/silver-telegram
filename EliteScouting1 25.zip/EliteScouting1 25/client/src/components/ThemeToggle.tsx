import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Sun, Moon, Monitor } from 'lucide-react';
import { useLanguage } from '@/hooks/use-language';

export default function ThemeToggle() {
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('system');
  const { t } = useLanguage();

  useEffect(() => {
    // Check saved theme or system preference
    const savedTheme = localStorage.getItem('theme') as 'light' | 'dark' | 'system' | null;
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

    if (savedTheme) {
      setTheme(savedTheme);
      applyTheme(savedTheme);
    } else if (prefersDark) {
      setTheme('system');
      document.documentElement.classList.add('dark');
    }

    // Listen for system theme changes
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e: MediaQueryListEvent) => {
      if (theme === 'system') {
        document.documentElement.classList.toggle('dark', e.matches);
      }
    };

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [theme]);

  const applyTheme = (newTheme: 'light' | 'dark' | 'system') => {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const root = document.documentElement;

    if (newTheme === 'system') {
      root.classList.toggle('dark', prefersDark);
    } else {
      root.classList.toggle('dark', newTheme === 'dark');
    }

    localStorage.setItem('theme', newTheme);
  };

  const cycleTheme = () => {
    const themes: Array<'light' | 'dark' | 'system'> = ['light', 'dark', 'system'];
    const currentIndex = themes.indexOf(theme);
    const nextTheme = themes[(currentIndex + 1) % themes.length];

    setTheme(nextTheme);
    applyTheme(nextTheme);
  };

  return (
    <Button
      variant="ghost" 
      size="icon"
      onClick={cycleTheme}
      title={t(theme === 'system' ? 'system_theme' : theme === 'dark' ? 'light_mode' : 'dark_mode')}
      className="transition-colors duration-200"
      aria-label={t(theme === 'system' ? 'system_theme' : theme === 'dark' ? 'light_mode' : 'dark_mode')}
    >
      {theme === 'system' ? (
        <Monitor className="h-5 w-5" />
      ) : theme === 'dark' ? (
        <Sun className="h-5 w-5" />
      ) : (
        <Moon className="h-5 w-5" />
      )}
      <span className="sr-only">
        {t(theme === 'system' ? 'system_theme' : theme === 'dark' ? 'light_mode' : 'dark_mode')}
      </span>
    </Button>
  );
}