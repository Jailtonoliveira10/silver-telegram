import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'pt' | 'en' | 'es';

type LanguageContextType = {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
};

const translations = {
  pt: {
    // Cabeçalho
    "welcome": "Bem-vindo",
    "dashboard": "Painel",
    "logout": "Sair",
    // Autenticação
    "login": "Entrar",
    "register": "Registrar",
    "username": "Usuário",
    "password": "Senha",
    "email": "Email",
    "sign_in_description": "Entre para acessar a plataforma de scouting",
    "or_continue_with": "ou continue com",
    "continue_with_google": "Continuar com Google",
    "logging_in": "Entrando...",
    "registering": "Registrando...",
    // Funcionalidades
    "player_analytics": "Análise de Jogadores",
    "market_intelligence": "Inteligência de Mercado",
    "smart_alerts": "Alertas Inteligentes",
    "view_dashboard": "Ver Painel",
    // Painel
    "player_stats": "Estatísticas",
    "market_value": "Valor de Mercado",
    "alert_settings": "Configurações de Alerta",
    // Estatísticas do Jogador
    "search_player": "Buscar Jogador",
    "search_player_placeholder": "Digite o nome do jogador...",
    "name": "Nome",
    "nationality": "Nacionalidade",
    "position": "Posição",
    "age": "Idade",
    "club": "Clube",
    "games": "Jogos",
    "goals": "Gols",
    "assists": "Assistências",
    "rating": "Avaliação",
    "all_positions": "Todas as posições",
    "forward": "Atacante",
    "midfielder": "Meio-campo",
    "defender": "Defensor",
    "goalkeeper": "Goleiro",
    // Comparação de Jogadores
    "player_comparison": "Comparação de Jogadores",
    "select_player_1": "Selecionar Jogador 1",
    "select_player_2": "Selecionar Jogador 2",
    "comparison_metrics": "Métricas de Comparação",
    "technical_analysis": "Análise Técnica",
    "physical_data": "Dados Físicos",
    "market_analysis": "Análise de Mercado",
    "performance_index": "Índice de Desempenho",
    "potential_growth": "Potencial de Crescimento",
    "compare_players": "Comparar Jogadores",
    // Análise de Mercado
    "market_value_distribution": "Distribuição de Valor de Mercado",
    "market_value_millions": "Valor de Mercado (€M)",
    "value_history": "Histórico de Valor",
    "market_trends": "Tendências de Mercado",
    "transfer_probability": "Probabilidade de Transferência",
    // Alertas
    "alert_preferences": "Preferências de Alerta",
    "notification_settings": "Configurações de Notificação",
    "email_notifications": "Notificações por Email",
    "positions_of_interest": "Posições de Interesse",
    "market_value_range": "Faixa de Valor de Mercado",
    "age_range": "Faixa de Idade",
    "save_preferences": "Salvar Preferências",
    "test_alert": "Enviar Alerta de Teste",
    // 2FA
    "two_factor_auth": "Autenticação de Dois Fatores",
    "2fa_enabled": "2FA está ativado",
    "2fa_description": "Ative a autenticação de dois fatores para maior segurança da sua conta",
    "enable_2fa": "Ativar 2FA",
    "disable_2fa": "Desativar 2FA",
    "scan_qr_code": "Escaneie o QR code com seu aplicativo autenticador",
    "enter_verification_code": "Digite o código de verificação",
    "verify": "Verificar",
    "languages": {
      "portuguese": "🇧🇷 Português",
      "english": "🇺🇸 English",
      "spanish": "🇪🇸 Español"
    }
  },
  en: {
    "welcome": "Welcome",
    "dashboard": "Dashboard",
    "logout": "Logout",
    "login": "Login",
    "register": "Register",
    "username": "Username",
    "password": "Password",
    "email": "Email",
    "sign_in_description": "Sign in to access the scouting platform",
    "or_continue_with": "or continue with",
    "continue_with_google": "Continue with Google",
    "logging_in": "Logging in...",
    "registering": "Registering...",
    "player_analytics": "Player Analytics",
    "market_intelligence": "Market Intelligence",
    "smart_alerts": "Smart Alerts",
    "view_dashboard": "View Dashboard",
    "player_stats": "Statistics",
    "market_value": "Market Value",
    "alert_settings": "Alert Settings",
    "search_player": "Search Player",
    "search_player_placeholder": "Type player name...",
    "name": "Name",
    "nationality": "Nationality",
    "position": "Position",
    "age": "Age",
    "club": "Club",
    "games": "Games",
    "goals": "Goals",
    "assists": "Assists",
    "rating": "Rating",
    "all_positions": "All positions",
    "forward": "Forward",
    "midfielder": "Midfielder",
    "defender": "Defender",
    "goalkeeper": "Goalkeeper",
    "player_comparison": "Player Comparison",
    "select_player_1": "Select Player 1",
    "select_player_2": "Select Player 2",
    "comparison_metrics": "Comparison Metrics",
    "technical_analysis": "Technical Analysis",
    "physical_data": "Physical Data",
    "market_analysis": "Market Analysis",
    "performance_index": "Performance Index",
    "potential_growth": "Potential Growth",
    "compare_players": "Compare Players",
    "market_value_distribution": "Market Value Distribution",
    "market_value_millions": "Market Value (€M)",
    "value_history": "Value History",
    "market_trends": "Market Trends",
    "transfer_probability": "Transfer Probability",
    "alert_preferences": "Alert Preferences",
    "notification_settings": "Notification Settings",
    "email_notifications": "Email Notifications",
    "positions_of_interest": "Positions of Interest",
    "market_value_range": "Market Value Range",
    "age_range": "Age Range",
    "save_preferences": "Save Preferences",
    "test_alert": "Send Test Alert",
    // 2FA
    "two_factor_auth": "Two-Factor Authentication",
    "2fa_enabled": "2FA is enabled",
    "2fa_description": "Enable two-factor authentication for enhanced account security",
    "enable_2fa": "Enable 2FA",
    "disable_2fa": "Disable 2FA",
    "scan_qr_code": "Scan the QR code with your authenticator app",
    "enter_verification_code": "Enter verification code",
    "verify": "Verify",
    "languages": {
      "portuguese": "🇧🇷 Portuguese",
      "english": "🇺🇸 English",
      "spanish": "🇪🇸 Spanish"
    }
  },
  es: {
    "welcome": "Bienvenido",
    "dashboard": "Panel",
    "logout": "Cerrar sesión",
    "login": "Iniciar sesión",
    "register": "Registrarse",
    "username": "Usuario",
    "password": "Contraseña",
    "email": "Correo",
    "sign_in_description": "Inicia sesión para acceder a la plataforma de scouting",
    "or_continue_with": "o continuar con",
    "continue_with_google": "Continuar con Google",
    "logging_in": "Iniciando sesión...",
    "registering": "Registrando...",
    "player_analytics": "Análisis de Jugadores",
    "market_intelligence": "Inteligencia de Mercado",
    "smart_alerts": "Alertas Inteligentes",
    "view_dashboard": "Ver Panel",
    "player_stats": "Estadísticas",
    "market_value": "Valor de Mercado",
    "alert_settings": "Configuración de Alertas",
    "search_player": "Buscar Jugador",
    "search_player_placeholder": "Escriba el nombre del jugador...",
    "name": "Nombre",
    "nationality": "Nacionalidad",
    "position": "Posición",
    "age": "Edad",
    "club": "Club",
    "games": "Partidos",
    "goals": "Goles",
    "assists": "Asistencias",
    "rating": "Valoración",
    "all_positions": "Todas las posiciones",
    "forward": "Delantero",
    "midfielder": "Mediocampista",
    "defender": "Defensor",
    "goalkeeper": "Portero",
    "player_comparison": "Comparación de Jugadores",
    "select_player_1": "Seleccionar Jugador 1",
    "select_player_2": "Seleccionar Jugador 2",
    "comparison_metrics": "Métricas de Comparación",
    "technical_analysis": "Análisis Técnico",
    "physical_data": "Datos Físicos",
    "market_analysis": "Análisis de Mercado",
    "performance_index": "Índice de Desempeño",
    "potential_growth": "Potencial de Crecimiento",
    "compare_players": "Comparar Jugadores",
    "market_value_distribution": "Distribución de Valor de Mercado",
    "market_value_millions": "Valor de Mercado (€M)",
    "value_history": "Histórico de Valor",
    "market_trends": "Tendências de Mercado",
    "transfer_probability": "Probabilidad de Transferencia",
    "alert_preferences": "Preferencias de Alerta",
    "notification_settings": "Configuración de Notificación",
    "email_notifications": "Notificaciones por Email",
    "positions_of_interest": "Posiciones de Interés",
    "market_value_range": "Rango de Valor de Mercado",
    "age_range": "Rango de Edad",
    "save_preferences": "Guardar Preferencias",
    "test_alert": "Enviar Alerta de Prueba",
    // 2FA
    "two_factor_auth": "Autenticación de Dos Factores",
    "2fa_enabled": "2FA está activado",
    "2fa_description": "Active la autenticación de dos factores para mayor seguridad de su cuenta",
    "enable_2fa": "Activar 2FA",
    "disable_2fa": "Desactivar 2FA",
    "scan_qr_code": "Escanee el código QR con su aplicación de autenticación",
    "enter_verification_code": "Ingrese el código de verificación",
    "verify": "Verificar",
    "languages": {
      "portuguese": "🇧🇷 Portugués",
      "english": "🇺🇸 Inglés",
      "spanish": "🇪🇸 Español"
    }
  }
};

const LanguageContext = createContext<LanguageContextType | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('pt');

  useEffect(() => {
    const savedLang = localStorage.getItem('language') as Language;
    if (savedLang) {
      setLanguage(savedLang);
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('language', lang);
  };

  const t = (key: string): string => {
    const keys = key.split('.');
    let value = translations[language];
    for (const k of keys) {
      value = value?.[k as keyof typeof value];
    }
    return value as string || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}