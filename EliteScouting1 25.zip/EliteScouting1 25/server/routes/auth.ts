import { Router } from 'express';
import passport from 'passport';
import { logger } from '../utils/logger';
import { hashPassword, verifyPassword, generateToken, authMiddleware, blacklistToken, extractTokenFromHeader } from '../services/auth';
import { users } from '@shared/schema';
import { eq } from 'drizzle-orm';
import { db } from '../db';
import crypto from 'crypto';
import { sendPasswordResetEmail, send2FAConfirmationEmail } from '../services/email';
import speakeasy from 'speakeasy';
import QRCode from 'qrcode';

const router = Router();

// Rota de autenticação Google
router.get('/google',
  passport.authenticate('google', { 
    scope: ['email', 'profile'],
    prompt: 'select_account' 
  })
);

// Callback do Google
router.get('/google/callback',
  passport.authenticate('google', { 
    failureRedirect: '/auth',
    failureMessage: true
  }),
  (req, res) => {
    logger.info('Login com Google bem-sucedido', {
      data: {
        userId: req.user?.id,
        email: req.user?.email
      }
    });

    // Gera token JWT para o usuário
    const token = generateToken(req.user!);

    // Redireciona para a página inicial com o token
    res.redirect(`/?token=${token}`);
  }
);

/**
 * @swagger
 * /api/auth/register:
 *   post:
 *     tags: [Autenticação]
 *     summary: Registra um novo usuário
 *     description: Cria uma nova conta de usuário com username, senha e email
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - username
 *               - password
 *               - email
 *             properties:
 *               username:
 *                 type: string
 *                 example: "admin6"
 *               password:
 *                 type: string
 *                 example: "novasenha123"
 *               email:
 *                 type: string
 *                 format: email
 *                 example: "admin6@test.com"
 *     responses:
 *       201:
 *         description: Usuário registrado com sucesso
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Usuário registrado com sucesso"
 *                 token:
 *                   type: string
 *       400:
 *         description: Dados inválidos ou incompletos
 *       409:
 *         description: Username já existe
 */
router.post('/register', async (req, res) => {
  try {
    logger.info('Tentativa de registro recebida', {
      data: {
        username: req.body.username,
        email: req.body.email,
        method: req.method,
        path: req.path
      }
    });

    const { username, password, email } = req.body;

    // Valida dados obrigatórios
    if (!username || !password || !email) {
      logger.warn('Dados incompletos no registro', {
        data: {
          missingFields: {
            username: !username,
            password: !password,
            email: !email
          }
        }
      });
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }

    // Verifica se usuário já existe
    const existingUser = await db.query.users.findFirst({
      where: eq(users.username, username)
    });

    if (existingUser) {
      logger.warn('Tentativa de registro com username existente', {
        data: { username }
      });
      return res.status(409).json({ error: 'Usuário já existe' });
    }

    // Cria novo usuário
    const hashedPassword = await hashPassword(password);
    const [newUser] = await db.insert(users).values({
      username,
      password: hashedPassword,
      email,
      alertPreferences: {
        positions: [],
        minMarketValue: 0,
        maxMarketValue: 100000000,
        ageRange: [16, 40],
        notificationEnabled: true,
        whatsappNumber: "",
        whatsappEnabled: false,
        alertTypes: {
          marketValue: true,
          performance: true,
          injury: true,
          transfer: true
        }
      }
    }).returning();

    const token = generateToken(newUser);

    logger.info('Novo usuário registrado com sucesso', {
      data: {
        username,
        id: newUser.id,
        statusCode: 201
      }
    });

    // Define headers de CORS e Content-Type
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'POST');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.header('Content-Type', 'application/json');

    // Retorna resposta com status 201 Created
    res.status(201).json({
      message: 'Usuário registrado com sucesso',
      token
    });
  } catch (err) {
    const error = err as Error;
    logger.error('Erro ao registrar usuário', error);
    res.status(500).json({ error: 'Erro ao registrar usuário' });
  }
});

/**
 * @swagger
 * /api/auth/login:
 *   post:
 *     tags: [Autenticação]
 *     summary: Faz login do usuário
 *     description: Autentica o usuário e retorna um token JWT
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - username
 *               - password
 *             properties:
 *               username:
 *                 type: string
 *                 example: "admin6"
 *               password:
 *                 type: string
 *                 example: "novasenha123"
 *     responses:
 *       200:
 *         description: Login realizado com sucesso
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Login realizado com sucesso"
 *                 token:
 *                   type: string
 *       401:
 *         description: Credenciais inválidas
 */
router.post('/login', async (req, res) => {
  try {
    logger.info('Tentativa de login recebida', {
      data: {
        username: req.body.username,
        method: req.method,
        path: req.path
      }
    });

    const { username, password } = req.body;

    // Valida dados obrigatórios
    if (!username || !password) {
      logger.warn('Dados incompletos no login', {
        data: {
          missingFields: {
            username: !username,
            password: !password
          }
        }
      });
      return res.status(400).json({ error: 'Username e senha são obrigatórios' });
    }

    // Busca usuário no banco
    const user = await db.query.users.findFirst({
      where: eq(users.username, username)
    });

    if (!user) {
      logger.warn('Tentativa de login com usuário inexistente', {
        data: { username }
      });
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    // Verifica senha
    const isValidPassword = await verifyPassword(password, user.password);
    if (!isValidPassword) {
      logger.warn('Tentativa de login com senha incorreta', {
        data: { username }
      });
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    // Gera token JWT
    const token = generateToken(user);

    logger.info('Login realizado com sucesso', {
      data: {
        username,
        id: user.id
      }
    });

    // Define headers de CORS e Content-Type
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'POST');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.header('Content-Type', 'application/json');

    // Retorna resposta com status 200 OK
    res.json({
      message: 'Login realizado com sucesso',
      token
    });
  } catch (err) {
    const error = err as Error;
    logger.error('Erro ao fazer login', error);
    res.status(500).json({ error: 'Erro ao fazer login' });
  }
});

/**
 * @swagger
 * /api/auth/me:
 *   get:
 *     tags: [Autenticação]
 *     summary: Obtém informações do usuário autenticado
 *     description: Retorna os dados do usuário atualmente autenticado.
 *     security:
 *       - BearerAuth: []
 *     responses:
 *       200:
 *         description: Dados do usuário retornados com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: integer
 *                   example: 1
 *                 username:
 *                   type: string
 *                   example: "johndoe"
 *                 email:
 *                   type: string
 *                   format: email
 *                   example: "johndoe@example.com"
 *                 alertPreferences:
 *                   type: object
 *       401:
 *         description: Usuário não autenticado.
 *       404:
 *         description: Usuário não encontrado.
 */
router.get('/me', authMiddleware, async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Usuário não autenticado' });
    }

    const user = await db.query.users.findFirst({
      where: eq(users.id, req.user.id)
    });

    if (!user) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  } catch (err) {
    const error = err as Error;
    logger.error('Erro ao buscar usuário', error);
    res.status(500).json({ error: 'Erro ao buscar usuário' });
  }
});

/**
 * @swagger
 * /api/auth/forgot-password:
 *   post:
 *     tags: [Autenticação]
 *     summary: Solicita recuperação de senha
 *     description: Envia um email com instruções para redefinir a senha.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *                 format: email
 *                 example: "johndoe@example.com"
 *     responses:
 *       200:
 *         description: Email de recuperação enviado com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Email de recuperação enviado com sucesso"
 *       400:
 *         description: Email inválido ou não fornecido.
 *       404:
 *         description: Email não encontrado.
 *       500:
 *         description: Erro ao enviar email.
 */
router.post('/forgot-password', async (req, res) => {
  try {
    logger.info('Requisição de recuperação de senha recebida', {
      data: {
        email: req.body.email,
        method: req.method,
        path: req.path
      }
    });

    const { email } = req.body;

    // Valida email
    if (!email) {
      logger.warn('Email não fornecido', {
        data: { path: req.path }
      });
      return res.status(400).json({ error: 'Email é obrigatório' });
    }

    // Busca usuário pelo email
    const user = await db.query.users.findFirst({
      where: eq(users.email, email)
    });

    if (!user) {
      logger.warn('Email não encontrado ao solicitar recuperação', {
        data: { email }
      });
      return res.status(404).json({ error: 'Email não encontrado' });
    }

    // Gera token e data de expiração (1 hora)
    const resetToken = crypto.randomBytes(32).toString('hex');
    const resetTokenExpiresAt = new Date(Date.now() + 3600000);

    // Atualiza usuário com o token
    await db
      .update(users)
      .set({
        resetToken,
        resetTokenExpiresAt
      })
      .where(eq(users.id, user.id));

    // Envia email com o token
    const emailSent = await sendPasswordResetEmail(email, resetToken);

    if (!emailSent) {
      logger.error('Erro ao enviar email de recuperação');
      return res.status(500).json({ error: 'Erro ao enviar email de recuperação' });
    }

    logger.info('Email de recuperação enviado com sucesso', {
      data: { email }
    });

    res.json({ message: 'Email de recuperação enviado com sucesso' });
  } catch (err) {
    const error = err as Error;
    logger.error('Erro ao processar recuperação de senha', error);
    res.status(500).json({ error: 'Erro ao processar recuperação de senha' });
  }
});

/**
 * @swagger
 * /api/auth/reset-password:
 *   post:
 *     tags: [Autenticação]
 *     summary: Redefine a senha do usuário
 *     description: Permite ao usuário redefinir sua senha usando um token.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               token:
 *                 type: string
 *                 example: "a1b2c3d4e5f6..."
 *               password:
 *                 type: string
 *                 example: "newpassword123"
 *     responses:
 *       200:
 *         description: Senha redefinida com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Senha redefinida com sucesso"
 *       400:
 *         description: Token inválido ou expirado, ou senha não fornecida.
 */
router.post('/reset-password', async (req, res) => {
  try {
    logger.info('Requisição de redefinição de senha recebida', {
      data: {
        method: req.method,
        path: req.path
      }
    });

    const { token, password } = req.body;

    // Valida dados
    if (!token || !password) {
      logger.warn('Dados incompletos na redefinição', {
        data: {
          missingFields: {
            token: !token,
            password: !password
          }
        }
      });
      return res.status(400).json({ error: 'Token e senha são obrigatórios' });
    }

    // Busca usuário pelo token
    const user = await db.query.users.findFirst({
      where: eq(users.resetToken, token)
    });

    if (!user || !user.resetTokenExpiresAt || user.resetTokenExpiresAt < new Date()) {
      logger.warn('Token inválido ou expirado', {
        data: { token }
      });
      return res.status(400).json({ error: 'Token inválido ou expirado' });
    }

    // Hash da nova senha
    const hashedPassword = await hashPassword(password);

    // Atualiza usuário
    await db
      .update(users)
      .set({
        password: hashedPassword,
        resetToken: null,
        resetTokenExpiresAt: null
      })
      .where(eq(users.id, user.id));

    logger.info('Senha redefinida com sucesso', {
      data: { userId: user.id }
    });

    res.json({ message: 'Senha redefinida com sucesso' });
  } catch (err) {
    const error = err as Error;
    logger.error('Erro ao redefinir senha', error);
    res.status(500).json({ error: 'Erro ao redefinir senha' });
  }
});

/**
 * @swagger
 * /api/auth/logout:
 *   post:
 *     tags: [Autenticação]
 *     summary: Faz logout do usuário
 *     description: Invalida o token JWT atual adicionando-o à blacklist
 *     security:
 *       - BearerAuth: []
 *     responses:
 *       200:
 *         description: Logout realizado com sucesso
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Logout realizado com sucesso"
 *       401:
 *         description: Token inválido ou não fornecido
 */
router.post('/logout', authMiddleware, async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ error: 'Token não fornecido' });
    }

    const token = extractTokenFromHeader(authHeader);
    if (!token) {
      return res.status(401).json({ error: 'Token inválido' });
    }

    await blacklistToken(token);

    logger.info('Logout realizado com sucesso', {
      data: {
        userId: req.user?.id,
        username: req.user?.username
      }
    });

    res.json({ message: 'Logout realizado com sucesso' });
  } catch (error) {
    logger.error('Erro ao realizar logout');
    res.status(500).json({ error: 'Erro ao realizar logout' });
  }
});

/**
 * @swagger
 * /api/auth/protected-test:
 *  get:
 *    tags: [Autenticação]
 *    summary: Rota protegida para teste
 *    description: Rota de teste que requer autenticação.
 *    security:
 *      - BearerAuth: []
 *    responses:
 *      200:
 *        description: Acesso permitido à rota protegida.
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                message:
 *                  type: string
 *                  example: "Acesso permitido à rota protegida"
 *                user:
 *                  type: object
 *                  properties:
 *                    id:
 *                      type: integer
 *                      example: 1
 *                    username:
 *                      type: string
 *                      example: "johndoe"
 *      401:
 *        description: Usuário não autenticado.
 */
router.get('/protected-test', authMiddleware, (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Usuário não autenticado' });
    }

    logger.info('Acesso a rota protegida bem-sucedido', {
      data: {
        userId: req.user.id,
        username: req.user.username,
        method: req.method,
        path: req.path
      }
    });

    res.json({
      message: 'Acesso permitido à rota protegida',
      user: {
        id: req.user.id,
        username: req.user.username
      }
    });
  } catch (err) {
    const error = err as Error;
    logger.error('Erro ao acessar rota protegida', error);
    res.status(500).json({ error: 'Erro ao acessar rota protegida' });
  }
});


// Modified 2FA enable route
router.post('/2fa/enable', authMiddleware, async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Usuário não autenticado' });
    }

    // Gera token de confirmação
    const confirmToken = crypto.randomBytes(32).toString('hex');
    const confirmTokenExpiresAt = new Date(Date.now() + 3600000); // 1 hora

    // Atualiza usuário com o token de confirmação
    await db.update(users)
      .set({
        twoFactorConfirmToken: confirmToken,
        twoFactorConfirmTokenExpiresAt: confirmTokenExpiresAt
      })
      .where(eq(users.id, req.user.id));

    // Envia email de confirmação
    const emailSent = await send2FAConfirmationEmail(
      req.user.email,
      confirmToken,
      'enable'
    );

    if (!emailSent) {
      return res.status(500).json({ error: 'Erro ao enviar email de confirmação' });
    }

    logger.info('Email de confirmação 2FA enviado', {
      data: {
        userId: req.user.id,
        email: req.user.email
      }
    });

    res.json({ message: 'Email de confirmação enviado. Por favor, verifique sua caixa de entrada.' });
  } catch (err) {
    const error = err as Error;
    logger.error('Erro ao processar solicitação de ativação 2FA', error);
    res.status(500).json({ error: 'Erro ao processar solicitação de ativação 2FA' });
  }
});

// New route to confirm 2FA changes
router.post('/2fa/confirm', authMiddleware, async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Usuário não autenticado' });
    }

    const { token, type } = req.body;

    // Valida token
    const user = await db.query.users.findFirst({
      where: eq(users.id, req.user.id)
    });

    if (!user?.twoFactorConfirmToken || 
        user.twoFactorConfirmToken !== token || 
        !user.twoFactorConfirmTokenExpiresAt || 
        user.twoFactorConfirmTokenExpiresAt < new Date()) {
      return res.status(400).json({ error: 'Token inválido ou expirado' });
    }

    // Gera o segredo TOTP
    const secret = speakeasy.generateSecret({
      name: `ESN:${user.email}`
    });

    // Gera o QR code
    const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url!);

    // Atualiza o usuário
    await db.update(users)
      .set({
        twoFactorSecret: secret.base32,
        twoFactorEnabled: true, //Enable 2FA after confirmation
        twoFactorConfirmToken: null,
        twoFactorConfirmTokenExpiresAt: null
      })
      .where(eq(users.id, req.user.id));

    logger.info('Configuração 2FA confirmada via email', {
      data: {
        userId: req.user.id,
        email: req.user.email,
        type
      }
    });

    res.json({
      secret: secret.base32,
      qrCodeUrl
    });
  } catch (err) {
    const error = err as Error;
    logger.error('Erro ao confirmar configuração 2FA', error);
    res.status(500).json({ error: 'Erro ao confirmar configuração 2FA' });
  }
});

// Rota para verificar e ativar 2FA (This route is now obsolete)
//router.post('/2fa/verify', authMiddleware, async (req, res) => { ... });

// Rota para validar código 2FA durante o login
router.post('/2fa/validate', async (req, res) => {
  try {
    const { userId, token } = req.body;

    const user = await db.query.users.findFirst({
      where: eq(users.id, userId)
    });

    if (!user?.twoFactorSecret || !user?.twoFactorEnabled) {
      return res.status(400).json({ error: '2FA não está ativo para este usuário' });
    }

    // Verifica o código TOTP
    const verified = speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: 'base32',
      token: token
    });

    if (!verified) {
      return res.status(401).json({ error: 'Código inválido' });
    }

    // Gera token JWT para o usuário
    const jwtToken = generateToken(user);

    logger.info('Validação 2FA bem-sucedida', {
      data: {
        userId: user.id,
        email: user.email
      }
    });

    res.json({
      message: 'Código 2FA validado com sucesso',
      token: jwtToken
    });
  } catch (err) {
    const error = err as Error;
    logger.error('Erro ao validar código 2FA', error);
    res.status(500).json({ error: 'Erro ao validar código 2FA' });
  }
});

// Rota para desativar 2FA
router.post('/2fa/disable', authMiddleware, async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Usuário não autenticado' });
    }

    // Desativa 2FA para o usuário
    await db.update(users)
      .set({
        twoFactorSecret: null,
        twoFactorEnabled: false
      })
      .where(eq(users.id, req.user.id));

    logger.info('2FA desativado com sucesso', {
      data: {
        userId: req.user.id,
        email: req.user.email
      }
    });

    res.json({ message: '2FA desativado com sucesso' });
  } catch (err) {
    const error = err as Error;
    logger.error('Erro ao desativar 2FA', error);
    res.status(500).json({ error: 'Erro ao desativar 2FA' });
  }
});

export { router as authRouter };