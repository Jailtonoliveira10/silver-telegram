// Carrega as variáveis de ambiente primeiro
import dotenv from "dotenv";
dotenv.config();

import express from "express";
import path from "path";
import fs from "fs";
import { logger } from "./utils/logger";
import { authRouter } from "./routes/auth";
import { userRouter } from "./routes/user";
import { swaggerUiServe, swaggerUiSetup } from './swagger';
import { authLimiter, generalLimiter } from './middleware/rate-limit';
import { setupVite, serveStatic } from "./vite";

// Log imediato das variáveis de ambiente
const isTestEnv = process.env.DISABLE_RATE_LIMIT_FOR_TESTS === 'true';
console.log('Environment variables loaded:', {
  DISABLE_RATE_LIMIT_FOR_TESTS: process.env.DISABLE_RATE_LIMIT_FOR_TESTS,
  isTestEnv,
  hasJwtSecret: !!process.env.JWT_SECRET,
  hasDatabase: !!process.env.DATABASE_URL,
  hasFootballKey: !!process.env.API_FOOTBALL_KEY,
  nodeEnv: process.env.NODE_ENV,
  port: process.env.PORT
});

// Log das variáveis de ambiente relacionadas ao rate limiting
logger.info('Configuração de rate limiting', { 
  source: 'server',
  data: {
    disableRateLimit: process.env.DISABLE_RATE_LIMIT_FOR_TESTS === 'true',
    nodeEnv: process.env.NODE_ENV
  }
});

// Verifica se JWT_SECRET está definido
if (!process.env.JWT_SECRET) {
  logger.error('JWT_SECRET não está definido', { 
    message: 'Environment variable missing',
    variable: 'JWT_SECRET'
  });
  process.exit(1);
}

// Verifica se DATABASE_URL está definido
if (!process.env.DATABASE_URL) {
  logger.error('DATABASE_URL não está definido', { 
    message: 'Environment variable missing',
    variable: 'DATABASE_URL'
  });
  process.exit(1);
}

// Handlers globais para erros não capturados
process.on('uncaughtException', (err) => {
  logger.error('Erro não capturado no processo', { 
    message: err.message,
    stack: err.stack,
    type: 'uncaughtException'
  });
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Promessa rejeitada não tratada', { 
    message: reason instanceof Error ? reason.message : String(reason),
    type: 'unhandledRejection',
    promise: String(promise)
  });
  process.exit(1);
});

const app = express();
app.set('trust proxy', 1);

// Configurações básicas
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Headers básicos de CORS antes de qualquer middleware de rate limiting
app.use((_req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (_req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Configuração do rate limiting baseada no ambiente
if (!isTestEnv) {
  logger.info('Aplicando rate limiting...', { source: 'server' });
  app.use(generalLimiter);
  app.use('/api/auth', authLimiter);
} else {
  logger.info('Rate limiting desabilitado para testes', { source: 'server' });
}

// Configura o diretório de uploads como estático
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

// Configuração do Swagger
app.use('/api-docs', swaggerUiServe, swaggerUiSetup);

// Rotas da API vêm primeiro
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
    rateLimit: process.env.DISABLE_RATE_LIMIT_FOR_TESTS === 'true' ? 'disabled' : 'enabled',
    variables: {
      hasJwtSecret: !!process.env.JWT_SECRET,
      hasDatabase: !!process.env.DATABASE_URL,
      hasFootballKey: !!process.env.API_FOOTBALL_KEY
    }
  });
});

// Rotas de autenticação
app.use('/api/auth', authRouter);

// Rotas de usuário
app.use('/api/user', userRouter);

// Configuração para servir arquivos estáticos do frontend
const frontendPath = path.join(process.cwd(), 'dist', 'public');
logger.info('Configurando caminho do frontend', {
  frontendPath,
  exists: fs.existsSync(frontendPath),
  cwd: process.cwd(),
  files: fs.readdirSync(process.cwd())
});

// Serve arquivos estáticos do frontend
app.use(express.static(frontendPath));

// Rota para servir o frontend em todas as rotas não-API
app.get('*', (_req, res) => {
  logger.info('Servindo frontend', {
    path: frontendPath,
    url: _req.url,
    cwd: process.cwd(),
    exists: fs.existsSync(path.join(frontendPath, 'index.html')),
    files: fs.existsSync(frontendPath) ? fs.readdirSync(frontendPath) : []
  });
  res.sendFile(path.join(frontendPath, 'index.html'));
});

// Middleware de tratamento de erros global
app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  logger.error('Erro na aplicação', {
    message: err.message,
    stack: err.stack,
    type: 'middleware'
  });

  res.status(500).json({
    message: 'Erro interno do servidor',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Porta do servidor deve usar variável de ambiente do Replit
logger.info('Configuração da porta', {
  source: 'server',
  portEnv: process.env.PORT,
  nodeEnv: process.env.NODE_ENV
});

// Em desenvolvimento, usa 5000 como fallback, em produção exige PORT definida
const port = process.env.NODE_ENV === 'production'
  ? Number(process.env.PORT)
  : Number(process.env.PORT || 5000);

if (isNaN(port)) {
  logger.error('Porta inválida configurada', { 
    message: 'Invalid port number',
    providedPort: process.env.PORT,
    type: 'configuration'
  });
  process.exit(1);
}

// Usa 0.0.0.0 para garantir que o servidor seja acessível externamente
const server = app.listen(port, '0.0.0.0', () => {
  logger.info(`Servidor rodando na porta ${port}`, { 
    source: 'server',
    data: {
      port,
      environment: process.env.NODE_ENV,
      nodeVersion: process.version,
      rateLimit: isTestEnv ? 'disabled' : 'enabled',
      timestamp: new Date().toISOString()
    }
  });
});

server.on('error', (err: Error) => {
  logger.error('Erro ao iniciar servidor', {
    message: err.message,
    stack: err.stack,
    type: 'server',
    port,
    timestamp: new Date().toISOString()
  });
  process.exit(1);
});

if (process.env.NODE_ENV === 'production') {
  serveStatic(app);
} else {
  setupVite(app, server);
}