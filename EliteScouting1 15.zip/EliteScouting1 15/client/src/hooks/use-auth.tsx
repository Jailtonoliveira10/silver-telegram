import { createContext, ReactNode, useContext, useEffect } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { insertUserSchema, User as SelectUser, InsertUser } from "@shared/schema";
import { getQueryFn, apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

type AuthContextType = {
  user: SelectUser | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<SelectUser, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<SelectUser, Error, InsertUser>;
  enable2FAMutation: UseMutationResult<{ secret: string; qrCodeUrl: string }, Error, void>;
  verify2FAMutation: UseMutationResult<void, Error, { token: string }>;
  disable2FAMutation: UseMutationResult<void, Error, void>;
  validate2FAMutation: UseMutationResult<{ token: string }, Error, { userId: number; token: string }>;
};

type LoginData = Pick<InsertUser, "username" | "password">;

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [location, setLocation] = useLocation();

  const {
    data: user,
    error,
    isLoading,
  } = useQuery<SelectUser | undefined, Error>({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  // Processa o token JWT do Google após o redirecionamento
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token');

    if (token) {
      // Remove o token da URL
      window.history.replaceState({}, document.title, window.location.pathname);

      // Armazena o token
      localStorage.setItem('token', token);

      // Atualiza o cache do react-query
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });

      // Redireciona para o dashboard
      setLocation('/dashboard');

      toast({
        title: "Login bem-sucedido!",
        description: "Bem-vindo de volta.",
      });
    }
  }, []);

  // Mutação para habilitar 2FA
  const enable2FAMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/auth/2fa/enable");
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Falha ao habilitar 2FA");
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "2FA",
        description: "Escaneie o QR code com seu aplicativo autenticador",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao habilitar 2FA",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutação para verificar e ativar 2FA
  const verify2FAMutation = useMutation({
    mutationFn: async ({ token }: { token: string }) => {
      const res = await apiRequest("POST", "/api/auth/2fa/verify", { token });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Falha ao verificar código 2FA");
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "2FA Ativado",
        description: "Autenticação de dois fatores ativada com sucesso",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro na verificação 2FA",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutação para validar código 2FA durante login
  const validate2FAMutation = useMutation({
    mutationFn: async ({ userId, token }: { userId: number; token: string }) => {
      const res = await apiRequest("POST", "/api/auth/2fa/validate", { userId, token });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Código 2FA inválido");
      }
      return res.json();
    },
    onSuccess: (data) => {
      localStorage.setItem('token', data.token);
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      setLocation('/dashboard');
      toast({
        title: "Login Completo",
        description: "Autenticação de dois fatores validada com sucesso",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro na validação 2FA",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutação para desabilitar 2FA
  const disable2FAMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/auth/2fa/disable");
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Falha ao desabilitar 2FA");
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "2FA Desativado",
        description: "Autenticação de dois fatores desativada com sucesso",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao desabilitar 2FA",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      const res = await apiRequest("POST", "/api/auth/login", credentials);
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Falha no login");
      }
      return data;
    },
    onSuccess: (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Bem-vindo!",
        description: `Login realizado com sucesso como ${user.username}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Falha no login",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (credentials: InsertUser) => {
      const res = await apiRequest("POST", "/api/auth/register", credentials);
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Falha no registro");
      }
      return data;
    },
    onSuccess: (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Bem-vindo!",
        description: `Registro realizado com sucesso como ${user.username}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Falha no registro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      try {
        const res = await apiRequest("POST", "/api/auth/logout");
        if (!res.ok) {
          const data = await res.json();
          throw new Error(data.error || "Falha no logout");
        }
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : "Falha no logout");
      }
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/user"], null);
      // Remove o token ao fazer logout
      localStorage.removeItem('token');
      toast({
        title: "Até logo!",
        description: "Logout realizado com sucesso",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Falha no logout",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
        enable2FAMutation,
        verify2FAMutation,
        disable2FAMutation,
        validate2FAMutation,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}