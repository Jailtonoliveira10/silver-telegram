import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { IoFootball } from "react-icons/io5";
import { Link } from "wouter";
import { LanguageSelector } from "@/components/language-selector";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { LineChart, Search, BellRing } from "lucide-react";
import { useTheme } from "@/providers/theme-provider";
import { Sun, Moon } from "lucide-react";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const { t } = useLanguage();
  const { theme, setTheme } = useTheme();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      <header className="container mx-auto px-4 py-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <IoFootball className="w-8 h-8 text-primary" />
          <span className="font-bold text-xl">ESN</span>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? (
              <Sun className="h-5 w-5" />
            ) : (
              <Moon className="h-5 w-5" />
            )}
          </Button>
        </div>
        <div className="flex items-center gap-4">
          <LanguageSelector />
          <span>{t('welcome')}, {user?.username}</span>
          <Button variant="outline" onClick={() => logoutMutation.mutate()}>
            {t('logout')}
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="text-center space-y-6 max-w-2xl mx-auto">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-primary to-primary/50 bg-clip-text text-transparent">
            Elite Scouting Network
          </h1>
          <p className="text-xl text-muted-foreground">
            {t('market_intelligence')}
          </p>
          <div className="flex justify-center gap-4">
            <Button asChild size="lg">
              <Link href="/dashboard">{t('view_dashboard')}</Link>
            </Button>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mt-16">
          <Link href="/dashboard?tab=stats">
            <Card className="hover:border-primary/50 transition-colors cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="h-5 w-5 text-primary" />
                  {t('player_analytics')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {t('player_stats')}
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/dashboard?tab=market">
            <Card className="hover:border-primary/50 transition-colors cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart className="h-5 w-5 text-primary" />
                  {t('market_intelligence')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {t('market_value')}
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/dashboard?tab=alerts">
            <Card className="hover:border-primary/50 transition-colors cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BellRing className="h-5 w-5 text-primary" />
                  {t('smart_alerts')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {t('alert_settings')}
                </p>
              </CardContent>
            </Card>
          </Link>
        </div>
      </main>
    </div>
  );
}