import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Player } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlayerStats from "@/components/player-stats";
import MarketValue from "@/components/market-value";
import MarketHistory from "@/components/market-history";
import AlertSettings from "@/components/alert-settings";
import ExportReports from "@/components/export-reports";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { LanguageSelector } from "@/components/language-selector";
import PlayerComparison from "@/components/player-comparison";
import LiveMatches from "@/components/live-matches"; // Added import

export default function DashboardPage() {
  const { user, logoutMutation } = useAuth();
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState("alerts");

  const [filters, setFilters] = useState({
    positions: [] as string[],
    minValue: 0,
    maxValue: 100000000,
    minAge: 16,
    maxAge: 40
  });

  const { data: players = [], isLoading } = useQuery<Player[]>({
    queryKey: [
      "/api/players",
      filters.positions.join(","),
      filters.minValue,
      filters.maxValue,
      filters.minAge,
      filters.maxAge
    ]
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="font-bold text-xl">ESN</Link>
            <span className="text-muted-foreground">{t('dashboard')}</span>
          </div>
          <div className="flex items-center gap-4">
            <LanguageSelector />
            <span>{t('welcome')}, {user?.username}</span>
            <Button variant="outline" onClick={() => logoutMutation.mutate()}>
              {t('logout')}
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>{t('player_analytics')}</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
              <TabsList>
                <TabsTrigger value="stats">{t('player_stats')}</TabsTrigger>
                <TabsTrigger value="market">{t('market_value')}</TabsTrigger>
                <TabsTrigger value="alerts">{t('alert_settings')}</TabsTrigger>
              </TabsList>

              <TabsContent value="alerts">
                <AlertSettings />
              </TabsContent>

              <TabsContent value="stats">
                <PlayerStats players={players} isLoading={isLoading} onFilterChange={setFilters} />
                <div className="mt-4"> {/* Added div for spacing */}
                  <LiveMatches />
                </div>
                <PlayerComparison players={players} isLoading={isLoading} />
                <ExportReports players={players} type="stats" />
              </TabsContent>

              <TabsContent value="market">
                <MarketValue players={players} isLoading={isLoading} />
                <MarketHistory players={players} isLoading={isLoading} />
                <ExportReports players={players} type="market" />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}