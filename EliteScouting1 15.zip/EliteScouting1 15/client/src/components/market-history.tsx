import { Player } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

interface MarketHistoryProps {
  players: Player[];
  isLoading: boolean;
}

export default function MarketHistory({ players, isLoading }: MarketHistoryProps) {
  const { t } = useLanguage();

  // Simulação de dados históricos (em uma implementação real, viria da API)
  const generateHistoricalData = (player: Player) => {
    const months = 12;
    const data = [];
    let currentValue = player.marketValue;

    for (let i = months - 1; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      
      // Simula variações no valor de mercado
      const variation = Math.random() * 0.2 - 0.1; // -10% a +10%
      currentValue = currentValue * (1 + variation);

      data.push({
        date: date.toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' }),
        [player.name]: Math.round(currentValue / 1000000) // Converter para milhões
      });
    }
    return data;
  };

  // Pegar os 5 jogadores mais valiosos
  const topPlayers = [...players]
    .sort((a, b) => b.marketValue - a.marketValue)
    .slice(0, 5);

  // Combinar dados históricos
  const historicalData = generateHistoricalData(topPlayers[0] || players[0]);
  topPlayers.slice(1).forEach(player => {
    const playerData = generateHistoricalData(player);
    playerData.forEach((item, index) => {
      historicalData[index] = { ...historicalData[index], ...item };
    });
  });

  const colors = ["hsl(var(--primary))", "#82ca9d", "#8884d8", "#ffc658", "#ff7300"];

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle>{t('value_history')}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={historicalData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis 
                label={{ 
                  value: t('market_value_millions'), 
                  angle: -90, 
                  position: 'insideLeft' 
                }} 
              />
              <Tooltip />
              <Legend />
              {topPlayers.map((player, index) => (
                <Line
                  key={player.id}
                  type="monotone"
                  dataKey={player.name}
                  stroke={colors[index]}
                  strokeWidth={2}
                  dot={false}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
