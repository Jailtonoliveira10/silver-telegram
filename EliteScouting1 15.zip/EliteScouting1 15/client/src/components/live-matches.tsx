import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";

interface Match {
  id: number;
  homeTeam: { name: string };
  awayTeam: { name: string };
  score: {
    fullTime: {
      home: number | null;
      away: number | null;
    }
  };
  status: string;
  utcDate: string;
}

export default function LiveMatches() {
  const { t } = useLanguage();
  
  const { data: matches = [], isLoading } = useQuery<Match[]>({
    queryKey: ["/api/matches"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('live_matches')}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {matches.map(match => (
            <div key={match.id} className="flex justify-between items-center p-2 rounded-lg border">
              <div className="text-sm flex-1">{match.homeTeam.name}</div>
              <div className="px-4 font-bold">
                {match.score.fullTime.home ?? '-'} - {match.score.fullTime.away ?? '-'}
              </div>
              <div className="text-sm flex-1 text-right">{match.awayTeam.name}</div>
              <div className="ml-4 text-xs text-muted-foreground">
                {format(new Date(match.utcDate), 'HH:mm')}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
